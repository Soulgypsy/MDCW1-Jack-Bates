package org.me.gcu.labstuff.Jack_Bates_S2026715;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;
public class EarthquakeAdapter extends ArrayAdapter<String> {
    private final List<String> descriptions;
    private boolean colorize;

    public EarthquakeAdapter(Context context, List<String> titles, List<String> descriptions) {
        super(context, android.R.layout.simple_list_item_1, titles);
        this.descriptions = descriptions;
        this.colorize = false;
    }

    public void setColorize(boolean colorize) {
        this.colorize = colorize;
        notifyDataSetChanged();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = super.getView(position, convertView, parent);
        TextView textView = (TextView) view.findViewById(android.R.id.text1);

        if (colorize) {
            float magnitude = extractMagnitude(descriptions.get(position));

            // Apply color based on magnitude only if colorize is true
            if (magnitude >= 2.0) {
                textView.setTextColor(Color.RED);
            } else if (magnitude >= 1.5) {
                textView.setTextColor(Color.parseColor("#FFA500")); // Orange
            } else if (magnitude >= 1.0) {
                textView.setTextColor(Color.parseColor("#FFD700")); // Gold
            } else {
                textView.setTextColor(Color.GREEN);
            }
        } else {
            // default colour (white)
            textView.setTextColor(Color.WHITE);
        }

        return view;
    }

    private float extractMagnitude(String description) {
        try {
            String[] parts = description.split(";");
            for (String part : parts) {
                if (part.toLowerCase().contains("magnitude")) {
                    return Float.parseFloat(part.split(":")[1].trim());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0f; // Fallback
    }
}

