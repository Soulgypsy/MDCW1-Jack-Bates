package org.me.gcu.labstuff.Jack_Bates_S2026715;

import androidx.lifecycle.ViewModel;
import java.util.ArrayList;
import java.util.List;

public class EarthquakeViewModel extends ViewModel {
    public List<String> earthquakeTitles = new ArrayList<>();
    public List<String> earthquakeDetails = new ArrayList<>();
}
