package org.me.gcu.labstuff.Jack_Bates_S2026715;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.app.DatePickerDialog;
import android.widget.DatePicker;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

public class MainActivity extends AppCompatActivity {
    private ListView listView;
    private Button startButton;
    private ArrayAdapter<String> adapter;
    private List<String> earthquakeTitles = new ArrayList<>();
    private List<String> earthquakeDetails = new ArrayList<>();
    private String urlSource = "http://quakes.bgs.ac.uk/feeds/MhSeismology.xml";
    private EarthquakeViewModel viewModel;
    private Button startDateButton, endDateButton;
    private Calendar startDate = Calendar.getInstance();
    private Calendar endDate = Calendar.getInstance();
    private final SimpleDateFormat xmlDateFormat = new SimpleDateFormat("EEE, d MMM yyyy", Locale.UK); // Adjust format if needed



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewModel = new ViewModelProvider(this).get(EarthquakeViewModel.class);

        listView = findViewById(R.id.listView);
         startButton = findViewById(R.id.startButton);

        adapter = new EarthquakeAdapter(this, viewModel.earthquakeTitles, viewModel.earthquakeDetails);
        listView.setAdapter(adapter);

        listView.setAdapter(adapter);

        startButton.setOnClickListener(v -> {
            viewModel.earthquakeTitles.clear();
            viewModel.earthquakeDetails.clear();
            adapter.notifyDataSetChanged();
            new Thread(this::fetchData).start();
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
            intent.putExtra("title", viewModel.earthquakeTitles.get(position));
            intent.putExtra("description", viewModel.earthquakeDetails.get(position));
            startActivity(intent);
        });
        startDateButton = findViewById(R.id.startDateButton);
        endDateButton = findViewById(R.id.endDateButton);


        startDateButton.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            new DatePickerDialog(MainActivity.this, (view, year, month, dayOfMonth) -> {
                startDate.set(year, month, dayOfMonth);
                startDateButton.setText("Start: " + xmlDateFormat.format(startDate.getTime()));
                if (endDateButton.getText().toString().contains("End:")) {
                    filterByDateRange();
                }
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
        });

        endDateButton.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            new DatePickerDialog(MainActivity.this, (view, year, month, dayOfMonth) -> {
                endDate.set(year, month, dayOfMonth);
                endDateButton.setText("End: " + xmlDateFormat.format(endDate.getTime()));
                if (startDateButton.getText().toString().contains("Start:")) {
                    filterByDateRange();
                }
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
        });


    }

    private void fetchData() {
        try {
            URL url = new URL(urlSource);
            URLConnection yc = url.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
            StringBuilder result = new StringBuilder();
            String inputLine;

            while ((inputLine = in.readLine()) != null) {
                result.append(inputLine);
            }
            in.close();

            parseXML(result.toString());

            runOnUiThread(() -> adapter.notifyDataSetChanged());

        } catch (IOException e) {
            Log.e("MyTag", "IOException", e);
        }
    }

    private void parseXML(String xmlData) {
        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser parser = factory.newPullParser();
            parser.setInput(new StringReader(xmlData));

            String title = null, description = null;
            int eventType = parser.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG) {
                    String tagName = parser.getName();
                    if (tagName.equalsIgnoreCase("title")) {
                        title = parser.nextText();
                    } else if (tagName.equalsIgnoreCase("description")) {
                        description = parser.nextText();
                    }
                } else if (eventType == XmlPullParser.END_TAG && parser.getName().equalsIgnoreCase("item")) {
                    if (title != null && description != null) {
                        viewModel.earthquakeTitles.add(title);
                        viewModel.earthquakeDetails.add(description);
                        title = null;
                        description = null;
                    }
                }
                eventType = parser.next();
            }
            runOnUiThread(() -> adapter.notifyDataSetChanged());
        } catch (XmlPullParserException | IOException e) {
            e.printStackTrace();
        }
    }
    private void filterByDateRange() {
        List<String> filteredTitles = new ArrayList<>();
        List<String> filteredDetails = new ArrayList<>();

        for (int i = 0; i < viewModel.earthquakeDetails.size(); i++) {
            String detail = viewModel.earthquakeDetails.get(i);

            try {
                String[] parts = detail.split(";");
                for (String part : parts) {
                    if (part.trim().toLowerCase().startsWith("origin date")) {
                        String dateStr = part.split(":")[1].trim();
                        Date quakeDate = xmlDateFormat.parse(dateStr);

                        if (quakeDate != null && !quakeDate.before(startDate.getTime()) && !quakeDate.after(endDate.getTime())) {
                            filteredTitles.add(viewModel.earthquakeTitles.get(i));
                            filteredDetails.add(detail);
                        }
                    }
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        viewModel.earthquakeTitles.clear();
        viewModel.earthquakeDetails.clear();
        viewModel.earthquakeTitles.addAll(filteredTitles);
        viewModel.earthquakeDetails.addAll(filteredDetails);

        // colourising when the date range is active only
        runOnUiThread(() -> {
            ((EarthquakeAdapter) adapter).setColorize(true);
        });
    }




}
